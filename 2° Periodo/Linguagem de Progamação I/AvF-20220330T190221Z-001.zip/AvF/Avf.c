#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main (void){

    int escolha;

    printf(
    "Digite 1 para cadastrar\n"
    "Digite 2 para verificar\n"
    );

    printf("Escolha: ");
    scanf("%d", &escolha);

    switch (escolha){
    case 1:
        cadastrar();
        break;
    case 2:
        verificar_reg();
        break;
    default:
        printf("Opcao nao disponivel");
        break;
    }
    
}

int cadastrar(){

    int quantidade;
    double custo;
    char ferramenta;
    char registro[100];

    FILE *aqPtr;

    if ((aqPtr = fopen("hardware.dat", "a")) == NULL){
        printf("Não há arquiivo!\n");
    }

    else{
        printf("\nRegistro: ");
        scanf("%s", registro);
        printf("\nNome: ");
        scanf(" %[^\n]", ferramenta);
        printf("\nQuantidade: ");
        scanf("%d", &quantidade);
        printf("\nCusto: ");
        scanf("%lf", &custo);

        if(!feof(stdin)){
            fprintf(aqPtr, "[%s] [%s] [%d] [%0.2lf]\n", registro, ferramenta, quantidade, custo); 
            fclose(aqPtr);
        }
    }

    return 0;
}

int verificar_reg(){
    
    char registro[100];

    printf("Registro: ");
    scanf(" %[^\n]", registro);

    int verificacao = verificar(registro);
    if (verificacao){
        printf("Produto ja Cadastrado");
    }
    else{
        printf("Produto ainda nao cadastrado");
        cadastrar();
    }

    return 1;
}

int verificar(char registro[100]) {
  
  FILE *produtoPtr;
  
  char produto[100];
  
  produtoPtr = fopen("./hardware.dat", "r");
  
  if (produtoPtr == NULL) {
    printf("Erro ao abrir aquivo.");
    return 0;
  }
  
  fgets(produto, 100, produtoPtr);
  
  while (fgets(produto, 100, produtoPtr)) {
    if (strstr(produto, registro)) {
      // Verifica idade
      int i = 0;
      int c;
      for (c = 0; c < strlen(produto); c++) {
        if (produto[c] == '[') {
          i++;
          int pos;
          if (i == 4) {
            if (produto[c + 2] == ']')
              pos = 1;
            else if (produto[c + 3] == ']')
              pos = 2;
            else if (produto[c + 4] == ']')
              pos = 3;
            char * buff = produto;
            char subbuff[6];
            memcpy(subbuff, & buff[c + 1], pos);
            subbuff[pos] = '\0';
            fclose(produtoPtr);
            return atoi(subbuff);
          }
        }
      }
      return 0;
    }
  }
  fclose(produtoPtr);
  return 0;
}