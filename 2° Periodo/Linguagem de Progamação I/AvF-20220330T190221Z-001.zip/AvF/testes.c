#include <stdio.h>

int main(){

    float x;
    double y;

    FILE *abPtr;

    if ((abPtr = fopen("teste.dat", "a")) == NULL){
        printf("Não há arquiivo!\n");

    }

    else{

    scanf("%f", &x);
    scanf("%lf", &y);

    printf("%f", x);
    printf("\n%0.2lf", y);

    while(1){

        fprintf(abPtr, "[%0.2f] [%0.2lf]\n", x, y); 
        scanf("%f %lf", &x, &y);

        fclose(abPtr);

    }
    }


    return 0;

}