#include <stdio.h>
#include <stdlib.h>
#include <time.h>


enum Status {CONTINUE, WON, LOST};

int rollDice(void);

int main (void){

   int sum;
   int myPoint;
   static int aposta;
   static int saudoBanca = 1000;

   enum Status gameStatus;

    
   printf("digite o valor de sua aposta: ");
   scanf("%i", &aposta);

   while (aposta >= (saudoBanca + 1)){
    printf("Digite um valor menor que 1000: ");
    scanf("%i", &aposta);
   }

   srand(time(NULL));

   sum = rollDice();

   switch (sum){
      case 7:
      case 11:
         gameStatus = WON;
         break;

      case 2:
      case 3:
      case 12:
         gameStatus = LOST;
         break;

      default:
         gameStatus = CONTINUE;
         myPoint = sum;
         printf("Ponto e %d\n", myPoint);
         break;
   }
   
while (gameStatus == CONTINUE){
   sum = rollDice();

   if (sum == myPoint){
      gameStatus = WON;
   }
   else{
      if (sum == 7){
         gameStatus = LOST;
      }
   }
}

if (gameStatus == WON){
   printf("Jogador vence\n");
   saudoBanca += aposta;
   printf("Novo valor de Saudo Banca: %i", saudoBanca);
}
else{
   printf("Jogador perde\n");
   saudoBanca -= aposta;
   printf("Novo valor de Saudo Banca: %i", saudoBanca);
}

    printf(aposta);
    printf(saudoBanca);

return 0;
}

int rollDice(void){

   int die1;
   int die2;
   int workSum;

   die1 = 1 + (rand() % 6);
   die2 = 1 + (rand() % 6);
   workSum = die1 + die2;

   printf("Jogador rolou %d + %d = %d\n", die1, die2, workSum);
   return workSum;
}   

